clear all; clc;

I=imread('OJ.jpg');
I=rgb2gray(I);
max=max(max(I));
min=min(min(I));
low=50;
high=177;
AutoCont=(I-low).*((max-min)/(high-low));
figure
subplot 221
imshow(I)
subplot 222
imshow (AutoCont)
subplot 223
imhist(I)
subplot 224
imhist (AutoCont)